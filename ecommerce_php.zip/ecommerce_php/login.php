<?php include('connection.php') ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login | SHINE - Electronic</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/bootstrap-icons.min.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="shortcut icon" href="./images/favicon.ico" type="image/x-icon">
</head>
<body class="bg-light">
    <?php include("navbar.php") ?>

    <?php

        if (isset($_POST['user_input_submit'])){
            $username = $_POST['user_input_username'];
            $password = $_POST['user_input_password'];
            
            $stmt = $conn->prepare("SELECT * FROM users WHERE username=?");

            $stmt -> bind_param("s", $username);
            $stmt -> execute();
            $result = $stmt -> get_result();

            $user = $result -> fetch_assoc();

            if ($user && password_verify($password, $user["password"])) {
                $_SESSION["msg"] = "Login successful";
                $_SESSION["username"] = $user["username"];
                header("location:index.php");
            }else{
                echo "Invalid username or password.";
            }

            
        }
    ?>


    <div class="container-fluid">
        <div class="row min-vh-100">

            <div class="col-12 d-flex align-items-center justify-content-center bg-white">
                <div class="auth-card w-100 p-4 p-md-5" style="max-width: 450px;">
                    <div class="mb-5">
                        <a href="index.php" class="text-decoration-none mb-4 d-inline-block text-primary fw-bold"><i class="bi bi-arrow-left me-2"></i> Back to Home</a>
                        <h2 class="fw-bold">Sign In</h2>
                    </div>

                    <form method="POST">
                        <div class="mb-3">
                            <label class="form-label small fw-bold">User Name</label>
                            <div class="input-group">
                                <span class="input-group-text bg-light border-end-0"><i class="bi bi-envelope text-secondary"></i></span>
                                <input type="text" class="form-control bg-light border-start-0 ps-0" placeholder="Enter Your Name" required name="user_input_username">
                            </div>
                        </div>

                        <div class="mb-3">
                            <div class="d-flex justify-content-between">
                                <label class="form-label small fw-bold">Password</label>
                            </div>
                            <div class="input-group">
                                <span class="input-group-text bg-light border-end-0"><i class="bi bi-lock text-secondary"></i></span>
                                <input type="password" class="form-control bg-light border-start-0 ps-0" placeholder="••••••••" required name="user_input_password">
                            </div>
                        </div>

                        <button type="submit" class="btn btn-primary-custom w-100 py-3 mb-4" name="user_input_submit">
                            Log In
                        </button>

                        <div class="text-center">
                            <p class="small text-secondary">Don't have an account? <a href="register.php" class="fw-bold text-primary text-decoration-none">Create Account</a></p>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script src="js/bootstrap.bundle.min.js"></script>
</body>
</html>