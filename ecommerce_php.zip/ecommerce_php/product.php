<?php include('connection.php') ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Products | Admin</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/bootstrap-icons.min.css">
    <link rel="stylesheet" href="css/style.css">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/7.0.1/css/all.min.css"
        integrity="sha512-2SwdPD6INVrV/lHTZbO2nodKhrnDdJK9/kg2XD1r9uGqPo1cUbujc+IYdlYdEErWNu69gVcYgdxlmVmzTWnetw=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />

    <link rel="shortcut icon" href="./images/favicon.ico" type="image/x-icon">
</head>

<body class="bg-light">

    <?php include('navbar.php') ?>

    <?php
    $products = $conn->query("SELECT * FROM products");

    ?>

    <?php
    $media = 'uploads/';
    if (!is_dir($media)) mkdir($media);

    if (isset($_POST['user_input_submit'])) {
        $title = $_POST['user_input_title'];
        $price = $_POST['user_input_price'];
        $qty = $_POST['user_input_qty'];
        $des = $_POST['user_input_des'];
        $image = null;


        if (!empty($_FILES['user_input_image']['name'])) {
            $image = time() . "_" . basename($_FILES['user_input_image']['name']);
            move_uploaded_file($_FILES['user_input_image']['tmp_name'], $media . $image);
        }

        $stmt = $conn->prepare("INSERT INTO products (title, price, quantity, description, image) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("siiss", $title, $price, $qty, $des, $image);

        if ($stmt->execute()) {
            header("Location: product.php");
            exit();
        } else {
            echo "Error: " . $conn->error;
        }
    }

    ?>

    <?php

    $total_result = $conn->query("SELECT COUNT(*) as total FROM products");
    $total_row = $total_result->fetch_assoc();
    $total_products = $total_row['total'];
    ?>

    <div class="container py-5 mt-5">
        <div class="d-flex justify-content-between align-items-center mb-4 pt-4">
            <div>
                <h2 class="fw-bold mb-1">Product Inventory</h2>
                <p class="text-secondary">Manage your store's products, stock, and pricing.</p>
            </div>
            <button class="btn btn-primary-custom px-4 py-2" data-bs-toggle="modal" data-bs-target="#addProductModal">
                <i class="bi bi-plus-lg me-2"></i> Add New Product
            </button>
        </div>

        <div class="row g-3 mb-4">
            <div class="col-12">
                <div class="p-3 bg-white rounded-4 shadow-sm border-0">
                    <small class="text-secondary text-uppercase fw-bold">Total Products</small>
                    <h3 class="fw-bold mb-0"><?php echo $total_products; ?></h3>
                </div>
            </div>
        </div>

        <div class="card border-0 shadow-sm rounded-4 overflow-hidden">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="bg-white">
                        <tr>
                            <th class="ps-4 py-3 text-secondary">Product</th>
                            <th class="py-3 text-secondary">Stock</th>
                            <th class="py-3 text-secondary">Price</th>
                            <th class="py-3 text-secondary">Created Date</th>
                            <th class="py-3 text-secondary text-end pe-4">Actions</th>
                        </tr>
                    </thead>
                    <tbody>

                        <?php while ($item = $products->fetch_assoc()): ?>
                            <tr>
                                <td class="ps-4">
                                    <div class="d-flex align-items-center">
                                        <img src="uploads/<?php echo $item['image'] ?>" class="rounded-3 me-3" width="50" height="50" style="object-fit: cover;">
                                        <div>
                                            <h6 class="mb-0 fw-bold"><?php echo $item['title'] ?></h6>
                                        </div>
                                    </div>
                                </td>
                                <td><span class="badge bg-light text-secondary rounded-pill px-3"><?php echo $item['quantity'] ?></span></td>
                                <td class="fw-bold text-primary">$ <?php echo $item['price'] ?></td>
                                <td class="fw-bold text-primary"><?php echo $item['created_at'] ?></td>
                                <td class="text-end pe-4">
                                    <a href="product_update.php?id=<?php echo $item['id'] ?>" class="btn btn-light btn-sm rounded-3 me-1"><i class="bi bi-pencil text-primary"></i></a>
                                    <a href="product_delete.php?id=<?php echo $item['id'] ?>" class="btn btn-light btn-sm rounded-3"><i class="bi bi-trash text-danger"></i></a>
                                </td>
                            </tr>
                        <?php endwhile; ?>

                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <div class="modal fade" id="addProductModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content border-0 rounded-4 shadow">
                <div class="modal-header border-0 px-4 pt-4">
                    <h5 class="fw-bold">Add New Product</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body px-4 pb-4">

                    <form method="POST" enctype="multipart/form-data">
                        <div class="row g-3">
                            <div class="col-md-8">
                                <label class="form-label small fw-bold">Product Name</label>
                                <input type="text" class="form-control rounded-3" placeholder="e.g. iphones" required name="user_input_title">
                            </div>
                            <div class="col-md-4">
                                <label class="form-label small fw-bold">Price ($)</label>
                                <input type="number" class="form-control rounded-3" placeholder="0.00" step="0.01" required name="user_input_price">
                            </div>
                            <div class="col-md-12">
                                <label class="form-label small fw-bold">Stock Quantity</label>
                                <input type="number" class="form-control rounded-3" placeholder="0" name="user_input_qty">
                            </div>
                            <div class="col-12">
                                <label class="form-label small fw-bold">Description</label>
                                <textarea class="form-control rounded-3" rows="3" name="user_input_des"></textarea>
                            </div>
                            <div class="col-12">
                                <label class="form-label small fw-bold">Product Image</label>
                                <input type="file" class="form-control rounded-3" name="user_input_image">
                            </div>
                            <div class="col-12 mt-4">
                                <button type="submit" class="btn btn-primary-custom w-100 py-3" name="user_input_submit">Save Product</button>
                            </div>
                        </div>
                    </form>

                </div>
            </div>
        </div>
    </div>

    <script src="js/bootstrap.bundle.min.js"></script>
</body>

</html>