<?php include('connection.php') ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update | SHINE - Electronic</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/bootstrap-icons.min.css">
    <link rel="stylesheet" href="css/style.css">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/7.0.1/css/all.min.css"
        integrity="sha512-2SwdPD6INVrV/lHTZbO2nodKhrnDdJK9/kg2XD1r9uGqPo1cUbujc+IYdlYdEErWNu69gVcYgdxlmVmzTWnetw=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />

    <link rel="shortcut icon" href="./images/favicon.ico" type="image/x-icon">
</head>
<body class="bg-light">
    <?php include("navbar.php") ?>

    <?php

    $id_data = null;
    if (isset($_GET["id"])){
        $id = $_GET["id"];

        $stmt = $conn->prepare("SELECT * FROM products WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();
        $id_data = $result->fetch_assoc();
    }
    ?>

    <?php 
        $media = 'uploads/';
        if(!is_dir($media)) mkdir($media);

        if (isset($_POST['user_input_submit'])){
            $product_id = $_POST['product_id'];
            $title = $_POST['user_input_title'];
            $price = $_POST['user_input_price'];
            $qty = $_POST['user_input_qty'];
            $des = $_POST['user_input_des'];
            $image = $_POST["old_image"];
        

            if (isset($_FILES['user_input_image']) && $_FILES['user_input_image']['name'] != ""){
                $image = time()."_".basename($_FILES['user_input_image']['name']);
                move_uploaded_file($_FILES['user_input_image']['tmp_name'], $media.$image);
            }

            $stmt = $conn->prepare("UPDATE products SET title = ?, price = ?, quantity = ?, description = ?, image = ? WHERE id = ?");
            $stmt->bind_param("siissi", $title, $price, $qty, $des, $image, $product_id);

            if ($stmt->execute()) {
                header("Location: product.php");
                exit();
            } else {
                echo "Error updating record: " . $conn->error;
            }
    
        }
    ?>


    <div class="container-fluid mt-5">
        <div class="row min-vh-100">

            <div class="col-12 d-flex align-items-center justify-content-center bg-white">
                <div class="auth-card w-100 p-4 p-md-5" style="max-width: 850px;">
                    <div class="mb-5">
                        <h2 class="fw-bold">Product Update</h2>
                    </div>

                    <form method="POST" enctype="multipart/form-data">

                        <input type="hidden" name="product_id" value="<?php echo $id_data["id"] ?>">
                        <input type="hidden" name="old_image" value="<?php echo $id_data["image"] ?>">

                        <div class="row g-3">
                            <div class="col-md-8">
                                <label class="form-label small fw-bold">Product Name</label>
                                <input type="text" class="form-control rounded-3" name="user_input_title" value="<?php echo $id_data["title"]?>">
                            </div>
                            <div class="col-md-4">
                                <label class="form-label small fw-bold">Price ($)</label>
                                <input type="number" class="form-control rounded-3" name="user_input_price" value="<?php echo $id_data["price"]?>">
                            </div>
                            <div class="col-md-12">
                                <label class="form-label small fw-bold">Stock Quantity</label>
                                <input type="number" class="form-control rounded-3" placeholder="0" name="user_input_qty" value="<?php echo $id_data["quantity"]?>">
                            </div>
                            <div class="col-12">
                                <label class="form-label small fw-bold">Description</label>
                                <textarea class="form-control rounded-3" rows="3" name="user_input_des"><?php echo $id_data["description"]?></textarea>
                            </div>
                            <div class="col-12">
                                <label class="form-label small fw-bold">Product Image</label>
                                <input type="file" class="form-control rounded-3" name="user_input_image">
                                <?php if (!empty($id_data["image"])): ?>
                                    <img src="uploads/<?php echo $id_data["image"] ?>" alt="Product Image" width="100" class="mt-2 rounded">
                                <?php endif; ?>
                            </div>
                            <div class="col-12 mt-4">
                                <button type="submit" class="btn btn-primary-custom w-100 py-3" name="user_input_submit">Save Product</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script src="js/bootstrap.bundle.min.js"></script>
</body>
</html>