<?php
session_start();
include('connection.php');

$error_msg = "";

if (isset($_POST["user_input_submit"])) {
    $secretKey = "6LcSbeYtAAAAAJvb5Y8zIa1EpckBzWIg3oQp4-tA";
    $responseKey = $_POST["g-recaptcha-response"] ?? '';
    $userIP = $_SERVER["REMOTE_ADDR"];

    if (empty($responseKey)) {
        $error_msg = "Please Check Your reCAPTCHA";
    } else {
        $url = "https://www.google.com/recaptcha/api/siteverify?secret={$secretKey}&response={$responseKey}&remoteip={$userIP}";

        $response = file_get_contents($url);
        $responseData = json_decode($response);

        if ($responseData && $responseData->success) {
            $username = trim($_POST["user_input_username"]);
            $password = password_hash($_POST["user_input_password"], PASSWORD_DEFAULT);

            $stmt = $conn->prepare("SELECT id FROM users WHERE username = ?");
            $stmt->bind_param("s", $username);
            $stmt->execute();
            $stmt->store_result();

            if ($stmt->num_rows > 0) {
                $error_msg = "User already exists";
            } else {
                $stmt->close();

                $s = $conn->prepare("INSERT INTO users(username, password) VALUES(?, ?)");
                $s->bind_param("ss", $username, $password);

                if ($s->execute()) {
                    $_SESSION["msg"] = "Register successful";
                    header("Location: login.php");
                    exit();
                } else {
                    $error_msg = "Register Failed";
                }
                $s->close();
            }
        } else {
            $error_msg = "reCAPTCHA Verification Fail";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register | SHINE - Electronic</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/bootstrap-icons.min.css">
    <link rel="stylesheet" href="css/style.css">

    <script src="https://www.google.com/recaptcha/api.js" async defer></script>
    <link rel="shortcut icon" href="./images/favicon.ico" type="image/x-icon">
</head>

<body class="bg-light">
    <?php include("navbar.php") ?>


    <div class="container-fluid">
        <div class="row min-vh-100">
            <div class="col-12 d-flex align-items-center justify-content-center bg-white">
                <div class="auth-card w-100 p-4 p-md-5" style="max-width: 450px;">
                    <div class="mb-5">
                        <a href="index.php" class="text-decoration-none mb-4 d-inline-block text-primary fw-bold">
                            <i class="bi bi-arrow-left me-2"></i> Back to Home
                        </a>
                        <h2 class="fw-bold">Register</h2>
                    </div>

                    <?php if (!empty($error_msg)): ?>
                        <div class="alert alert-danger mx-auto" style="max-width: 500px;">
                            <?php echo $error_msg ?>
                        </div>
                    <?php endif; ?>

                    <form method="POST">
                        <div class="mb-3">
                            <label class="form-label small fw-bold">User Name</label>
                            <div class="input-group">
                                <span class="input-group-text bg-light border-end-0"><i class="bi bi-envelope text-secondary"></i></span>
                                <input type="text" class="form-control bg-light border-start-0 ps-0" placeholder="Enter Yoru Name" required name="user_input_username">
                            </div>
                        </div>

                        <div class="mb-3">
                            <div class="d-flex justify-content-between">
                                <label class="form-label small fw-bold">Password</label>
                            </div>
                            <div class="input-group">
                                <span class="input-group-text bg-light border-end-0"><i class="bi bi-lock text-secondary"></i></span>
                                <input type="password" class="form-control bg-light border-start-0 ps-0" placeholder="••••••••" required name="user_input_password">
                            </div>
                        </div>

                        <div class="g-recaptcha mb-3" data-sitekey="6LcSbeYtAAAAAJfq7PRl2LEO8ENEhPVSJu55UzeB"></div>

                        <button type="submit" class="btn btn-primary-custom w-100 py-3 mb-4" name="user_input_submit">
                            Register
                        </button>

                        <div class="text-center">
                            <p class="small text-secondary">Already have an account?
                                <a href="login.php" class="fw-bold text-primary text-decoration-none">Login</a>
                            </p>
                        </div>
                    </form>
                </div>
            </div>


        </div>
    </div>

    <script src="js/bootstrap.bundle.min.js"></script>
    
</body>

</html>